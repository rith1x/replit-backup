<!-- signin.php -->
<?php
// session_start();  

// Replace with the path to your JSON file
$json_file = 'user.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = $_POST['email'];
  $password = $_POST['password'];

  // Read the JSON file and decode its contents to an array 
  $users = json_decode(file_get_contents($json_file), true);

  // Search for the user with the matching email and password
  $matching_user = null;
  foreach ($users as $user) {
    if ($user['email'] === $email && $user['password'] === $password) {
      $matching_user = $user;
      break;
    }
  }

  if ($matching_user) {
    // Store the user's details in the session
    $_SESSION['user'] = $matching_user;

    // Redirect to the user details page
    header('Location: user_details.php');
    exit;
  } else {
    // Display an error message
    $error_message = 'Incorrect email or password. Please try again.';
  }
}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Sign In</title>
  </head>
  <body>
    <h1>Sign In</h1>
    <?php if (isset($error_message)): ?>
      <p><?php echo $error_message; ?></p>
    <?php endif; ?>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>
      <br>
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required>
      <br>
      <button type="submit">Sign In</button>
    </form>
  </body>
</html>
