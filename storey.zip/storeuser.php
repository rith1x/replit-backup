<?php 
	if(isset($_POST['submit'])){
    date_default_timezone_set('Asia/Kolkata');
    $date = date('d-m-y h:i:s');
		$new_message = array(
			"email" => $_POST['email'],
      "name" => $_POST['name'],
			"password" => $_POST['password'],
      "joined-at" => $date
		);
		
		
		if(filesize("user.json") == 0){
			$first_record = array($new_message);
			$data_to_save = $first_record; 
		}else{
			$old_records = json_decode(file_get_contents("user.json"));

			array_push($old_records, $new_message);

			$data_to_save = $old_records;
		}

		if(!file_put_contents("user.json", json_encode($data_to_save, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX)){
			$error = "Try Again Later";
		}else{
			$success =  "User Added Successfully";
		}
	}
