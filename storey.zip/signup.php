<?php require("storeuser.php") ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="description" content="How to store form data in a json file with php">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styles.css">
  <meta name="theme-color" content="#c9b5e6" />
	<title>Signup</title>
</head>
<body>

	<h1>Signup User</h1>

	<!-- Let's begin with our form element -->
	<form action="" method="post">
		<h3>Enter Details</h3>

		<label>E-mail</label>
		<input type="email" name="email" value="" required>

		<label>Name</label>
		<input type="text" name="name" value="" required>

    <label>Password</label>
		<input type="password" name="password" required></input>

	

		<input type="submit" name="submit" value="Submit">

		<p class="error"><?php echo @$error; ?></p>
		<p class="success"><?php echo @$success; ?></p>
	</form>
	<div class="fill"></div>
</body>
</html>