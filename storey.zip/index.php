<?php require("script.php") ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="description" content="How to store form data in a json file with php">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styles.css">
  <meta name="theme-color" content="#c9b5e6" />
	<title>SMS V1.0 Stable</title>
</head>
<body>

	<h1>Notification System - Staff Login</h1>

	<!-- Let's begin with our form element -->
	<form action="" method="post">
		<h3>Notification System</h3>



<label for="staff" >Staff Name</label>

<select name="staff" class="staff" id="staff">
  <option value="Sasikumar B, DIC - AI•DS">Sasikumar B, DIC - AI•DS</option>
  
  <option value="Brindha V, Lecturer - AI•DS">Brindha V, Lecturer - AI•DS</option>
  <option value="Gopalakrishnan A, Lecturer - AI•DS">Gopalakrishnan A, Lecturer - AI•DS</option>
  <option value="Venkatachalam S, Lecturer - AI•DS">Venkatachalam S, Lecturer - AI•DS</option>
  <option value="Gomathi V, Lecturer - AI•DS">Gomathi V, Lecturer - AI•DS</option>
</select>
    
		<label>Enter your email</label>
		<input type="email" name="email" value="">

		<label>Enter a subject</label>
		<input type="text" name="subject" value="">

		<label>Enter your message</label>
		<textarea name="message"></textarea>

		<input type="submit" name="submit" value="Broadcast Message">

		<p class="error"><?php echo @$error; ?></p>
		<p class="success"><?php echo @$success; ?></p>
	</form>
	<div class="fill"></div>
</body>
</html>