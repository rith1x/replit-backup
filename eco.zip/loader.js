window.addEventListener("load", function() {
  var loader = document.getElementById("loader");
  loader.classList.remove("is-active");
});