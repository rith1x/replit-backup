
window.addEventListener("load", function() {
    var loader = document.getElementById("loader");
    loader.classList.remove("is-active");
  });
  
  function openNav() {
    document.getElementById("mySidebar").style.width = "100%";
    document.getElementById("main").style.marginLeft = "-50px";
  }
  
  function closeNav() {
    document.getElementById("mySidebar").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
  }
